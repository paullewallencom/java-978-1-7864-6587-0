package gettingobjectoriented;

import java.util.*;

public class GettingObjectOriented {
    public static void main(String[] args) {
            Scanner reader = new Scanner(System.in);
            
            System.out.println(reader.next());           
    }
}