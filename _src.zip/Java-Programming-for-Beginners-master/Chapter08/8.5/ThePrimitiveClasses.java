package the.primitiveclasses;

public class ThePrimitiveClasses {

    public static void main(String[] args) {
        String s = "string";
        
        
        char c = 'C';
        System.out.println(Character.isLowerCase(c));
    }
    
}
